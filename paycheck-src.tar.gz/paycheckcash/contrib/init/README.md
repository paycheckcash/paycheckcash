Sample configuration files for:
```
SystemD: paycheckcashd.service
Upstart: paycheckcashd.conf
OpenRC:  paycheckcashd.openrc
         paycheckcashd.openrcconf
CentOS:  paycheckcashd.init
macOS:    org.paycheckcash.paycheckcashd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
